﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApiDemo.Models;

namespace WebApiDemo.Controllers
{

    [RoutePrefix("student")]
    public class StudentController : ApiController
    {
        
        public StudentController() : base()
        {

        }
        // GET api/values
        public IHttpActionResult Get()
        {
            return Ok(StudentRepository.Get());
        }

        // GET api/values/5
        public StudentModels Get(int id)
        {
            return StudentRepository.GetById(id);
        }

        // POST api/values
        [HttpPost]
        public IHttpActionResult Post([FromBody]string Name)
        {
            StudentRepository.Add(Name);
            return Ok();
        }

        // PUT api/values/5
        public IHttpActionResult Put(int id, [FromBody]string Name)
        {
            if (StudentRepository.Update(id, Name))
            {
                return Ok();
            }
            else {
                return NotFound();
            }
        }

        // DELETE api/values/5
        public IHttpActionResult Delete(int id)
        {
            if (StudentRepository.Delete(id))
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
    }
}
