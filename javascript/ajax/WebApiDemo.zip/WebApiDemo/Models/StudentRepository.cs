﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiDemo.Models
{
    public static class StudentRepository
    {
        static List<StudentModels> students;
        static int studentNo = 0;
        
        static StudentRepository () {
            if (students == null) {
                string[] maleNames = { "aaron", "abdul", "abe", "abel", "abraham", "adam", "adan", "adolfo", "adolph", "adrian" };
                students = new List<StudentModels>();
                Random r = new Random();
                for (int i = 0; i < maleNames.Length; i++)
                {
                    Add(char.ToUpper(maleNames[i][0]) + maleNames[i].Substring(1) + " Moniz");
                }
            }
            
        }

        public static void Add(string Name) {
            students.Add(new StudentModels(studentNo++, Name));
        }

        public static List<StudentModels> Get()
        {
            return students;
        }

        public static StudentModels GetById(int id)
        {
            return students.Find(t => t.Id == id);
        }

        public static bool Update(int id, string Name)
        {
            var isUpdated = false;
            var student = GetById(id);
            if (student != null) {
                isUpdated = true;
                student.Name = Name;
            }

            return isUpdated;
        }

        public static bool Delete(int id)
        {
            var isUpdated = false;
            var student = GetById(id);
            if (student != null)
            {
                isUpdated = true;
                students.Remove(student);
            }
            return isUpdated;
        }


    }
}